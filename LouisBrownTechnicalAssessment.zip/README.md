# JobMatchEngine
All files required to run this application should exist within the zip file.

The data folder contains the csv files which have the job and jobseeker data. The path and file name is required to stay the same for the application to run properly.

Running/Executing the JobMatchEngine.exe file will open a command prompt which will show the formatted output data that has been sorted. The application has a console read line statement at the end of it to avoid the console closing and to allow you to see its output. Hitting enter should then close the console once finished.
